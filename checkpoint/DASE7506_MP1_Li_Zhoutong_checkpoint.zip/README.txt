DASE7506 MP1 - Final SwiGLU dropout checkpoint
Student: Li Zhoutong (3036781272)

Reported full-test BPB: 1.5895306196462753
Protocol: 7506-mp1-wt2-v2
Evaluation: CPU, FP32, four threads

This bundle matches the final code repository. Copy checkpoint.pt to any local
path and run the evaluator from the repository root:

python evaluate.py --checkpoint /path/to/checkpoint.pt --device cpu --precision fp32 --threads 4 --split test --output reproduced-test.json

Required model files in this bundle:
- checkpoint.pt
- student.py
- student_model.py
- swiglu_256x6_dropout.json

Final checkpoint SHA-256:
90163aed08c92f1affce1830907e63a62ef0b01ec32327c82a71088f8c747802

The checkpoint contains the implementation name and model configuration. The
repository supplies the fixed evaluator, tokenizer, data and dependencies.
Training was accelerated with a local GPU, but the reported score was measured
again with the required CPU FP32 evaluator.
