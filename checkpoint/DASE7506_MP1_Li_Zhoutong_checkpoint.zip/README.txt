DASE7506 MP1 - Final SwiGLU checkpoint
Student: Li Zhoutong (3036781272)

Reported full-test BPB: 1.7386699302095425
Protocol: 7506-mp1-wt2-v2
Evaluation: CPU, FP32, four threads

This bundle matches the final code repository. Copy checkpoint.pt to any local
path and run the evaluator from the repository root:

python evaluate.py --checkpoint /path/to/checkpoint.pt --device cpu --precision fp32 --threads 4 --split test --output reproduced-test.json

Required model files in this bundle:
- checkpoint.pt
- student.py
- student_model.py
- swiglu_192.json

Final checkpoint SHA-256:
373b884e4daec5c99ad2e0645106ead62580b68c2b07a0eb2220e3c7c1c87dcc

The checkpoint contains the implementation name and model configuration. The
repository supplies the fixed evaluator, tokenizer, data and dependencies.
